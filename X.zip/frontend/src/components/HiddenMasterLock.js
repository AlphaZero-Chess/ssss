import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Lock } from 'lucide-react';

// Secret code: Type "ALPHA" to unlock the hidden master
const SECRET_CODE = ['a', 'l', 'p', 'h', 'a'];
const STORAGE_KEY = 'hiddenMasterUnlocked';

// Pre-generate random positions for smoke particles
const generateParticleStyles = (count) => {
  return Array.from({ length: count }, (_, i) => ({
    left: `${5 + (i * 13) % 90}%`,
    top: `${5 + (i * 19) % 90}%`,
    animationDelay: `${(i * 0.2) % 3}s`,
    animationDuration: `${2.5 + (i * 0.15) % 2}s`,
    scale: 0.8 + (i % 3) * 0.3
  }));
};

const PARTICLE_STYLES = generateParticleStyles(35);

// Generate electric spark positions
const generateSparkPositions = (count) => {
  return Array.from({ length: count }, (_, i) => ({
    left: `${(i * 23) % 100}%`,
    top: `${(i * 31) % 100}%`,
    delay: (i * 0.15) % 2,
    duration: 0.3 + (i % 5) * 0.1
  }));
};

const SPARK_POSITIONS = generateSparkPositions(20);

const HiddenMasterLock = ({ children, onUnlock }) => {
  // Initialize state based on localStorage
  const [isLocked, setIsLocked] = useState(() => {
    const unlocked = localStorage.getItem(STORAGE_KEY);
    return unlocked !== 'true';
  });
  const [isUnlocking, setIsUnlocking] = useState(false);
  const [codeProgress, setCodeProgress] = useState([]);
  const [showHint, setShowHint] = useState(false);
  const hintTimerRef = useRef(null);

  // Trigger unlock function
  const triggerUnlock = useCallback(() => {
    setIsUnlocking(true);
    
    // After animation completes, set unlocked state
    setTimeout(() => {
      setIsLocked(false);
      setIsUnlocking(false);
      localStorage.setItem(STORAGE_KEY, 'true');
      if (onUnlock) onUnlock();
    }, 3000);
  }, [onUnlock]);

  // Secret code listener
  const handleKeyPress = useCallback((e) => {
    if (!isLocked || isUnlocking) return;

    const key = e.key.toLowerCase();
    
    setCodeProgress(prev => {
      const newProgress = [...prev, key];
      
      // Check if the sequence matches the start of the secret code
      const isValidProgress = SECRET_CODE.slice(0, newProgress.length).every(
        (char, i) => char === newProgress[i]
      );

      if (!isValidProgress) {
        return [key === SECRET_CODE[0] ? key : ''];
      }

      // Check if complete code entered
      if (newProgress.length === SECRET_CODE.length) {
        triggerUnlock();
        return [];
      }

      return newProgress;
    });
  }, [isLocked, isUnlocking, triggerUnlock]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleKeyPress]);

  // Show hint after hovering for 3 seconds - only show hint, no other hover effects
  const handleMouseEnter = useCallback(() => {
    if (isLocked && !isUnlocking) {
      hintTimerRef.current = setTimeout(() => setShowHint(true), 3000);
    }
  }, [isLocked, isUnlocking]);

  const handleMouseLeave = useCallback(() => {
    setShowHint(false);
    if (hintTimerRef.current) {
      clearTimeout(hintTimerRef.current);
    }
  }, []);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (hintTimerRef.current) {
        clearTimeout(hintTimerRef.current);
      }
    };
  }, []);

  // Memoize particle elements
  const smokeParticles = useMemo(() => (
    PARTICLE_STYLES.map((style, i) => (
      <div 
        key={i} 
        className={`smoke-particle-enhanced ${isUnlocking ? 'particle-disperse-enhanced' : ''}`}
        style={{
          left: style.left,
          top: style.top,
          animationDelay: style.animationDelay,
          animationDuration: style.animationDuration,
          transform: `scale(${style.scale})`
        }}
      />
    ))
  ), [isUnlocking]);

  // Memoize electric sparks
  const electricSparks = useMemo(() => (
    SPARK_POSITIONS.map((spark, i) => (
      <div 
        key={i} 
        className={`electric-spark ${isUnlocking ? 'spark-burst' : ''}`}
        style={{
          left: spark.left,
          top: spark.top,
          animationDelay: `${spark.delay}s`,
          animationDuration: `${spark.duration}s`
        }}
      />
    ))
  ), [isUnlocking]);

  if (!isLocked) {
    return <>{children}</>;
  }

  return (
    <div 
      className="hidden-master-lock-wrapper-enhanced"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      data-testid="hidden-master-lock"
    >
      {/* The card underneath - with special aura leaking through */}
      <div className="locked-card-container-enhanced">
        {children}
      </div>

      {/* Aura Leak Effect - Shows the mystical energy seeping through */}
      <div className={`aura-leak-container ${isUnlocking ? 'aura-reveal' : ''}`}>
        <div className="aura-leak aura-leak-1" />
        <div className="aura-leak aura-leak-2" />
        <div className="aura-leak aura-leak-3" />
      </div>

      {/* Dark Smoke Overlay - Overwhelming but allows aura to leak */}
      <div className={`smoke-overlay-enhanced ${isUnlocking ? 'smoke-disperse-enhanced' : ''}`}>
        <div className="smoke-layer-enhanced smoke-layer-e1" />
        <div className="smoke-layer-enhanced smoke-layer-e2" />
        <div className="smoke-layer-enhanced smoke-layer-e3" />
        <div className="smoke-vortex" />
        <div className="smoke-particles-enhanced">
          {smokeParticles}
        </div>
      </div>

      {/* MASSIVE ELECTRIFYING CHAINS - Front Layer */}
      <div className={`mega-chains-container ${isUnlocking ? 'chains-disintegrate' : ''}`}>
        {/* Electric Field Effect */}
        <div className="electric-field">
          {electricSparks}
        </div>

        {/* Primary Horizontal Chains - THICK */}
        <div className="mega-chain mega-chain-h mega-chain-h-1">
          {[...Array(18)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.03}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-h mega-chain-h-2">
          {[...Array(18)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.03 + 0.1}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-h mega-chain-h-3">
          {[...Array(18)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.03 + 0.2}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        
        {/* Primary Vertical Chains - THICK */}
        <div className="mega-chain mega-chain-v mega-chain-v-1">
          {[...Array(22)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.025}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-v mega-chain-v-2">
          {[...Array(22)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.025 + 0.15}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-v mega-chain-v-3">
          {[...Array(22)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.025 + 0.3}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>

        {/* Diagonal Chains - Cross Pattern */}
        <div className="mega-chain mega-chain-d mega-chain-d-1">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.02}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-d mega-chain-d-2">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.02 + 0.12}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-d mega-chain-d-3">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.02 + 0.24}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="mega-chain mega-chain-d mega-chain-d-4">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="mega-chain-link" style={{ animationDelay: `${i * 0.02 + 0.36}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>

        {/* Wrapping Chains - Around the edges */}
        <div className="wrap-chain wrap-chain-top">
          {[...Array(16)].map((_, i) => (
            <div key={i} className="mega-chain-link wrap-link" style={{ animationDelay: `${i * 0.04}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="wrap-chain wrap-chain-bottom">
          {[...Array(16)].map((_, i) => (
            <div key={i} className="mega-chain-link wrap-link" style={{ animationDelay: `${i * 0.04 + 0.1}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="wrap-chain wrap-chain-left">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="mega-chain-link wrap-link" style={{ animationDelay: `${i * 0.035}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>
        <div className="wrap-chain wrap-chain-right">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="mega-chain-link wrap-link" style={{ animationDelay: `${i * 0.035 + 0.1}s` }}>
              <div className="chain-electric-glow" />
            </div>
          ))}
        </div>

        {/* Chain connection points to padlock */}
        <div className="chain-anchor chain-anchor-n" />
        <div className="chain-anchor chain-anchor-s" />
        <div className="chain-anchor chain-anchor-e" />
        <div className="chain-anchor chain-anchor-w" />
      </div>

      {/* MASSIVE PADLOCK - Central Element */}
      <div className={`mega-padlock-container ${isUnlocking ? 'mega-padlock-fall' : ''}`}>
        <div className="mega-padlock">
          {/* Padlock Energy Field */}
          <div className="padlock-energy-field" />
          
          {/* Chain Connection Ring */}
          <div className="padlock-chain-ring">
            <div className="chain-ring-glow" />
          </div>
          
          {/* Shackle */}
          <div className="mega-padlock-shackle">
            <div className="shackle-inner-mega" />
            <div className="shackle-electric-arc shackle-arc-1" />
            <div className="shackle-electric-arc shackle-arc-2" />
          </div>
          
          {/* Body */}
          <div className="mega-padlock-body">
            <Lock className="mega-padlock-icon" size={32} />
            <div className="mega-padlock-keyhole">
              <div className="keyhole-glow" />
            </div>
            <div className="padlock-runes">
              <span className="rune rune-1">⛧</span>
              <span className="rune rune-2">☠</span>
              <span className="rune rune-3">⛧</span>
            </div>
          </div>
          
          {/* Electric Aura */}
          <div className="padlock-electric-aura" />
          <div className="padlock-power-ring" />
        </div>
      </div>

      {/* Interaction Blocker - Prevents ALL interaction when locked */}
      <div className="lock-interaction-blocker" data-testid="lock-blocker" />

      {/* Code Progress Indicator */}
      {codeProgress.length > 0 && !isUnlocking && (
        <div className="code-progress-enhanced" data-testid="code-progress">
          {SECRET_CODE.map((_, i) => (
            <div 
              key={i} 
              className={`progress-dot-enhanced ${i < codeProgress.length ? 'active' : ''}`}
            />
          ))}
        </div>
      )}

      {/* Hint */}
      {showHint && !isUnlocking && (
        <div className="unlock-hint-enhanced" data-testid="unlock-hint">
          <span className="hint-text-enhanced">⚡ TYPE THE SECRET WORD ⚡</span>
        </div>
      )}

      {/* Unlocking text */}
      {isUnlocking && (
        <div className="unlocking-text-enhanced" data-testid="unlocking-text">
          <div className="seal-break-flash" />
          <span className="seal-text">⚡ SEAL SHATTERED ⚡</span>
          <div className="power-release-ring" />
        </div>
      )}
    </div>
  );
};

export default HiddenMasterLock;
